import { new_user, current_user, logout_user } from "./Types"

export const New_user = (task) => {
    return {
        type: new_user,
        task: task
    }
}

export const Current_user = (userData) => {
    return {
        type: current_user,
        task: userData
    }
}

export const Logout_user = () => {
    return {
        type: logout_user
    }
}
