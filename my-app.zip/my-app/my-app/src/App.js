import React from 'react';
import { useSelector } from 'react-redux';
import { BrowserRouter, Routes, Route, Navigate } from 'react-router-dom';
import Login from './Componenet/Login/Login';
import SignUp from './Componenet/Signup/SignUp';
import HotelList from './Componenet/ListHotels/HotelList';
import RoomOptionsPage from './Componenet/ListOfRooms/RoomOptionPage';
import BookingHistoryPage from './Componenet/BookingHistoryPage/BookingHistoryPage ';
import Navbar from './Componenet/Navbar/Navbar';

function App() {
  const currentUser = useSelector(state => state.currentUser);

  return (
    <BrowserRouter>
     <div>
      <Navbar/>
      <Routes>
          <Route path="/login" element={<Login />} />
          <Route path="/" element={<SignUp />} />
          <Route path="/booking-history" element={ currentUser ? (<BookingHistoryPage />) : ( <Navigate to="/login" replace />)}/>
          <Route path="/list" element={ currentUser ? (<HotelList />): ( <Navigate to="/login" replace />)} />
          <Route path="/room-details/:roomId" element={ currentUser?(<RoomOptionsPage />): ( <Navigate to="/login" replace />)} />
        </Routes>
     </div>
    </BrowserRouter>
  );
}

export default App;
