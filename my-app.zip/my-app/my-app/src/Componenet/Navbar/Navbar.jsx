import React from 'react';
import { Link } from 'react-router-dom';
import { useSelector } from 'react-redux';
import { useDispatch } from 'react-redux';
import { Current_user } from '../../reduxDemo/User/userAction';



import './Navbar.css';

function Navbar() {
    const dispatch = useDispatch();
  const currentUser = useSelector(state => state.currentUser);

  const handleLogout = () => {
    dispatch(Current_user(null));
  };

  return (
    <nav className="navbar">
      <ul>
        <li>
          <Link to="/">Home</Link>
        </li>
        <li>
          <Link to="/list">HotelList</Link>
        </li>
        <li>
          <Link to="/booking-history">BookingHistory</Link>
        </li>
        {currentUser ? (
          <li>
            <button onClick={handleLogout}>Logout</button>
          </li>
        ) : (
          <li>
            <Link to="/login">Login</Link>
          </li>
        )}
      </ul>
    </nav>
  );
}

export default Navbar;
