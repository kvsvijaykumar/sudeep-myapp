
import { current_user, new_user,logout_user } from "./Types";

export const reducers = (state = {}, action) => {
    switch(action.type) {
        case new_user:
            return { ...state, newUser: action.task }; // Update state with new user data
        case current_user:
            return { ...state, currentUser: action.task }; // Update state with current user data
        case logout_user:
                return { ...state, currentUser: null };     
        default:
            return state;
    }
}
