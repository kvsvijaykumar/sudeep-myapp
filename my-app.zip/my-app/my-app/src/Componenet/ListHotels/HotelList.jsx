import React from 'react';
import './HotelList.css';
import { hotels } from '../Json/Hotels';
import { useNavigate } from 'react-router-dom';

const HotelList = () => {
    const navigate = useNavigate();
    

    const navigateToRoomOptions = (hotelId, hotel) => {
        navigate(`/room-details/${hotelId}`, { state: { hotel } }); 
    };

    return (
        <div className="hotel-list">
            {hotels.map((hotel) => (
                <div className="hotel-card" key={hotel.id}>
                    <img src={hotel.image} alt={hotel.name} />
                    <div className="hotel-info">
                        <h3>{hotel.name}</h3>
                        <p>{hotel.place}</p>
                        <button className='rooms' onClick={()=> navigateToRoomOptions(hotel.id, hotel)}>Rooms</button>
                        <p>{hotel.description}</p>
                    </div>
                </div>
            ))}
        </div>
    );
};

export default HotelList;


