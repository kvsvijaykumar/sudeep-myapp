import React, { useState } from 'react';
import './SignUp.css';
import axios from 'axios';
import { useDispatch } from 'react-redux';
import { Current_user } from '../../reduxDemo/User/userAction';
import { useNavigate } from 'react-router-dom'; 

function SignUp() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [name, setName] = useState('');
    const [phoneNumber, setPhoneNumber] = useState('');
    const dispatch = useDispatch();
    const navigate = useNavigate(); 

    const handleSignUp = async (e) => {
        e.preventDefault();
        try {
            const response = await axios.post('http://localhost:8080/signup/newUsers', {
                name,
                email,
                password,
                phoneNumber
            });
            const newUser = {email,password,name,password}; 
            console.log(response.data)
            if(response.data === "Succefully Registered the user"){
                dispatch(Current_user(newUser)); 
                setEmail('');setPassword("");setName('');setPhoneNumber('')
                navigate("/login")
            }
        } catch (error) {
            console.error("Error occurred while signing up:", error);
            navigate("/")
        }
    };

    const navigateToLogin = () => {
        navigate('/login'); 
    };

    return (
        <div className="signup-container">
            <div className="signup-left"></div>
            <div className="signup-right">
                <div className="login-form">
                    <h2>Sign Up</h2>
                    <input
                        type="text"
                        placeholder="Name"
                        value={name}
                        onChange={(e) => setName(e.target.value)}
                    />
                    <input
                        type="email"
                        placeholder="Email"
                        value={email}
                        onChange={(e) => setEmail(e.target.value)}
                    />
                    <input
                        type="password"
                        placeholder="Password"
                        value={password}
                        onChange={(e) => setPassword(e.target.value)}
                    />
                    <input
                        type="text"
                        placeholder="Phone Number"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                    />
                    <button onClick={handleSignUp}>Sign Up</button>
                    <a onClick={navigateToLogin}>Already Registered ?</a>
                </div>
            </div>
        </div>
    );
}

export default SignUp;
