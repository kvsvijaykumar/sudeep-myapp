import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom'; 
import { useSelector } from 'react-redux';
import axios from 'axios';

const BookingHistoryPage = () => {
    const [loading, setLoading] = useState(true);
    const [bookingHistory, setBookingHistory] = useState([]);
    const navigate = useNavigate(); 
    const currentUser = useSelector(state => state.currentUser);

    useEffect(() => {
        axios.get(`http://localhost:8080/booking-history/by-email?email=${currentUser.email}`)
            .then(response => {
                console.log(response);
                if (response.data === "") {
                    setBookingHistory([]);
                } else {
                    const data = response.data;
                    const historyArray = Array.isArray(data) ? data : [data]; 
                    setBookingHistory(historyArray);
                }
                setLoading(false); 
            })
            .catch(error => {
                console.error("Error fetching booking history:", error);
                setLoading(false); 
            });
    }, [currentUser.email]);

    return (
        <div>
            <h1>Booking History</h1>
            {loading ? (
                <p>Loading...</p>
            ) : (
                <div>
                    {bookingHistory.length === 0 ? (
                        <p>No records found</p>
                    ) : (
                        bookingHistory.map((booking, index) => (
                            <div key={index} style={{ marginBottom: '20px', border: '1px solid #ccc', padding: '10px' }}>
                                <h2>Booking ID: {booking.id}</h2>
                                {/* <p>Name: {booking.name}</p> */}
                                <p>Email: {booking.email}</p>
                                <p>Hotel Name: {booking.hotelName}</p>
                                <h3>Rooms:</h3>
                                <ul>
                                    {booking.rooms.map((room, roomIndex) => (
                                        <li key={roomIndex}>
                                            Type: {room.type}, Price: ${room.price}
                                        </li>
                                    ))}
                                </ul>
                                <p>Total Cost: ${booking.totalCost}</p>
                            </div>
                        ))
                    )}
                </div>
            )}
        </div>
    );
};

export default BookingHistoryPage;
