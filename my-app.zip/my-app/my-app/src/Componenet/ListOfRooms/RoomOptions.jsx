import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom'; 
import { useSelector } from 'react-redux';
import './Room.css';
import axios from 'axios';


const RoomOptions = ({ hotel }) => {
    const [roomSelections, setRoomSelections] = useState({}); // Object to store the selected number of rooms for each room type
    const navigate = useNavigate(); 
    const currentUser = useSelector(state => state.currentUser);

    const handleRoomSelection = (event, roomType) => {
        const selectedRoom = hotel.rooms.find(room => room.type === roomType);
        if (selectedRoom) {
            setRoomSelections(prevSelections => ({
                ...prevSelections,
                [roomType]: parseInt(event.target.value)
            }));
        }
    };

    const calculateTotalCost = () => {
        let total = 0;
        for (const type in roomSelections) {
            const selectedRooms = roomSelections[type];
            const room = hotel.rooms.find(room => room.type === type);
            total += selectedRooms * room.price;
        }
        return total;
    };


    const saveToDB = () => {
        const bookingData = {
            name: currentUser && currentUser.name | "anynamous", 
            email: currentUser.email,
            hotelName: hotel.name,
            rooms: Object.keys(roomSelections).map(type => ({ type, quantity: roomSelections[type], price: hotel.rooms.find(room => room.type === type).price })), // Array of selected rooms with their quantity and price
            totalCost: calculateTotalCost() 
        };

       
        axios.post("http://localhost:8080/booking-history/add", bookingData)
            .then(response => {
                console.log("Booking successful:", response.data);
                navigate("/booking-history")
            })
            .catch(error => {
                console.error("Error while booking:", error);
            });
    };

    return (
        <div className="room-options">
            {hotel.rooms.map((room, index) => (
                <div className="room-option" key={index}>
                    <img src={room.image} alt={room.type} />
                    <div>
                        <h3>{room.type}</h3>
                        <p>${room.price}</p>
                        <input
                            type="number"
                            placeholder="number"
                            value={roomSelections[room.type] || 0}
                            onChange={(e) => handleRoomSelection(e, room.type)}
                        />
                    </div>
                </div>
            ))}

            <div className='but'> 
                <button className='book'  onClick={saveToDB}>Book Now</button>
                <button className='book' onClick={()=>{navigate("/booking-history")}}>Book History</button>
            </div>

           </div>
    );
};
export default RoomOptions;

