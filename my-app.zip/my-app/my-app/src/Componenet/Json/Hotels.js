export const hotels = [
    {
        id: 1,
        name: 'Hotel A',
        place: 'City X',
        image: 'https://cf.bstatic.com/xdata/images/hotel/square600/482124163.webp?k=03b117a97bafb47b9aec68a3d75a49293c012b6885e762d8332be12f7145853e&o=',
        description: 'Situated in Bangalore in the Karnataka region, Serviced apartment with WiFi parking kitchen etc has a balcony. This property offers access to a terrace and free private parking.',
        rooms :[
            { type: 'Single', price: 100,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Double', price: 150,image:'https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aG90ZWwlMjByb29tfGVufDB8fDB8fHww' },
            { type: 'triple', price: 400,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Suite', price: 250,image:'https://img.freepik.com/free-photo/luxury-classic-modern-bedroom-suite-hotel_105762-1787.jpg' }
        ]
    },
    {
        id: 2,
        name: 'Hotel B',
        place: 'City Y',
        image: 'https://cf.bstatic.com/xdata/images/hotel/square600/479505855.webp?k=ae87538e5fe19c98211aa7bc4e8a32d7a3fb3dc4f13b9ec4ad5b9e927f27b7d3&o=',
        description: 'Situated in Bangalore in the Karnataka region, Serviced apartment with WiFi parking kitchen etc has a balcony. This property offers access to a terrace and free private parking.',
        rooms :[
            { type: 'Single', price: 100,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Double', price: 150,image:'https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aG90ZWwlMjByb29tfGVufDB8fDB8fHww' },
            { type: 'triple', price: 400,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Suite', price: 250,image:'https://img.freepik.com/free-photo/luxury-classic-modern-bedroom-suite-hotel_105762-1787.jpg' }
        ]
    },
    {
        id: 3,
        name: 'Hotel C',
        place: 'City Z',
        image: 'https://cf.bstatic.com/xdata/images/hotel/square600/507960158.webp?k=9ffd0bc000d4956425ec63af9bcb44dac7002585c549e400a6fee87e11fb8fed&o=', // Placeholder image URL
        description: 'Situated in Bangalore in the Karnataka region, Serviced apartment with WiFi parking kitchen etc has a balcony. This property offers access to a terrace and free private parking.',
        rooms :[
            { type: 'Single', price: 100,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Double', price: 150,image:'https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aG90ZWwlMjByb29tfGVufDB8fDB8fHww' },
            { type: 'triple', price: 400,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Suite', price: 250,image:'https://img.freepik.com/free-photo/luxury-classic-modern-bedroom-suite-hotel_105762-1787.jpg' }
        ]
    },
    {
        id: 4,
        name: 'Hotel D',
        place: 'City W',
        image: 'https://cf.bstatic.com/xdata/images/hotel/square600/513716224.webp?k=e51358741bd1d07a1fc8917905db80ecfeaed1adc611406e463f585acd74f87b&o=', // Placeholder image URL
        description: 'Situated in Bangalore in the Karnataka region, Serviced apartment with WiFi parking kitchen etc has a balcony. This property offers access to a terrace and free private parking.',
        rooms :[
            { type: 'Single', price: 100,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Double', price: 150,image:'https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aG90ZWwlMjByb29tfGVufDB8fDB8fHww' },
            { type: 'triple', price: 400,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Suite', price: 250,image:'https://img.freepik.com/free-photo/luxury-classic-modern-bedroom-suite-hotel_105762-1787.jpg' }
        ]
    },
    {
        id: 5,
        name: 'Hotel E',
        place: 'City V',
        image: 'https://cf.bstatic.com/xdata/images/hotel/square600/457970089.webp?k=0db48d106d40d1be99f7efab25dff949c3bec0fb99c126dd04abbc843b99ceca&o=', // Placeholder image URL
        description: 'Situated in Bangalore in the Karnataka region, Serviced apartment with WiFi parking kitchen etc has a balcony. This property offers access to a terrace and free private parking.',
        rooms :[
            { type: 'Single', price: 100,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Double', price: 150,image:'https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aG90ZWwlMjByb29tfGVufDB8fDB8fHww' },
            { type: 'triple', price: 400,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Suite', price: 250,image:'https://img.freepik.com/free-photo/luxury-classic-modern-bedroom-suite-hotel_105762-1787.jpg' }
        ]
    },
    {
        id: 6,
        name: 'Hotel F',
        place: 'City U',
        image: 'https://cf.bstatic.com/xdata/images/hotel/square600/510920911.webp?k=55481fe28c68c372ea4bd1376e12647b294eaaee9b671b17f0ce49b7f5bd80c6&o=', // Placeholder image URL
        description: 'Situated in Bangalore in the Karnataka region, Serviced apartment with WiFi parking kitchen etc has a balcony. This property offers access to a terrace and free private parking.',
        rooms :[
            { type: 'Single', price: 100,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Double', price: 150,image:'https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aG90ZWwlMjByb29tfGVufDB8fDB8fHww' },
            { type: 'triple', price: 400,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Suite', price: 250,image:'https://img.freepik.com/free-photo/luxury-classic-modern-bedroom-suite-hotel_105762-1787.jpg' }
        ]
    },
    {
        id: 7,
        name: 'Hotel G',
        place: 'City T',
        image: 'https://cf.bstatic.com/xdata/images/hotel/square600/482124163.webp?k=03b117a97bafb47b9aec68a3d75a49293c012b6885e762d8332be12f7145853e&o=',
        description: 'Situated in Bangalore in the Karnataka region, Serviced apartment with WiFi parking kitchen etc has a balcony. This property offers access to a terrace and free private parking.',
        rooms :[
            { type: 'Single', price: 100,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Double', price: 150,image:'https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aG90ZWwlMjByb29tfGVufDB8fDB8fHww' },
            { type: 'triple', price: 400,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Suite', price: 250,image:'https://img.freepik.com/free-photo/luxury-classic-modern-bedroom-suite-hotel_105762-1787.jpg' }
        ]
    },
    {
        id: 8,
        name: 'Hotel H',
        place: 'City S',
        image: 'https://cf.bstatic.com/xdata/images/hotel/square600/482124163.webp?k=03b117a97bafb47b9aec68a3d75a49293c012b6885e762d8332be12f7145853e&o=',
        description: 'Situated in Bangalore in the Karnataka region, Serviced apartment with WiFi parking kitchen etc has a balcony. This property offers access to a terrace and free private parking.',
        rooms :[
            { type: 'Single', price: 100,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Double', price: 150,image:'https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aG90ZWwlMjByb29tfGVufDB8fDB8fHww' },
            { type: 'triple', price: 400,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Suite', price: 250,image:'https://img.freepik.com/free-photo/luxury-classic-modern-bedroom-suite-hotel_105762-1787.jpg' }
        ]
    },
    {
        id: 9,
        name: 'Hotel I',
        place: 'City R',
        image: 'https://cf.bstatic.com/xdata/images/hotel/square600/205258848.webp?k=abad16cfc82d5e9d3be7dedc9ba4c8589f8a8bbcfd4e2e165e9bc499f1d6a5c6&o=', // Placeholder image URL
        description: 'Situated in Bangalore in the Karnataka region, Serviced apartment with WiFi parking kitchen etc has a balcony. This property offers access to a terrace and free private parking.',
        rooms :[
            { type: 'Single', price: 100,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Double', price: 150,image:'https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0.3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aG90ZWwlMjByb29tfGVufDB8fDB8fHww' },
            { type: 'triple', price: 400,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
            { type: 'Suite', price: 250,image:'https://img.freepik.com/free-photo/luxury-classic-modern-bedroom-suite-hotel_105762-1787.jpg' }
        ]
     }
    // ,
    // {
    //     id: 10,
    //     name: 'Hotel J',
    //     place: 'City Q',
    //     image: 'https://cf.bstatic.com/xdata/images/hotel/square600/205258848.webp?k=abad16cfc82d5e9d3be7dedc9ba4c8589f8a8bbcfd4e2e165e9bc499f1d6a5c6&o=', // Placeholder image URL
    //     description: 'Situated in Bangalore in the Karnataka region, Serviced apartment with WiFi parking kitchen etc has a balcony. This property offers access to a terrace and free private parking.',
    //     rooms :[
    //         { type: 'Single', price: 100,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
    //         { type: 'Double', price: 150,image:'https://images.unsplash.com/photo-1611892440504-42a792e24d32?q=80&w=1000&auto=format&fit=crop&ixlib=rb-4.0  .3&ixid=M3wxMjA3fDB8MHxzZWFyY2h8Mnx8aG90ZWwlMjByb29tfGVufDB8fDB8fHww' },
    //         { type: 'triple', price: 400,image :'https://images.pexels.com/photos/164595/pexels-photo-164595.jpeg' },
    //         { type: 'Suite', price: 250,image:'https://img.freepik.com/free-photo/luxury-classic-modern-bedroom-suite-hotel_105762-1787.jpg' }
    //     ]
    // }
];
