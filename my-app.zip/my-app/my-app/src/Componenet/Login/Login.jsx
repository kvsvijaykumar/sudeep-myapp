import React, { useState } from 'react';
import './Login.css'; 
import axios from 'axios';
import { useDispatch } from 'react-redux';
import { Current_user } from '../../reduxDemo/User/userAction'; 
import { useNavigate } from 'react-router-dom'; 

function Login() {
    const [email, setEmail] = useState('');
    const [password, setPassword] = useState('');
    const [error, setError] = useState('');

    const dispatch = useDispatch();
    const navigate = useNavigate(); 

    const handleLogin = (e) => {
        e.preventDefault();
        axios.post('http://localhost:8080/signup/email', { email, password })
            .then((response) => {
                console.log(response);
                if(response.data) {
                    dispatch(Current_user(response.data)); 
                    setEmail('');
                    setPassword('');
                    navigate("/list");         
                } else {
                    setError('Invalid credentials, please try again.');
                }
            })
            .catch((error) => {
                console.error("Error occurred while logging in:", error);
                setError('An error occurred, please try again later.');
            });
    };

    return (
        <div className="login-container">
            <div className="login-left"></div>
            <div className="login-right">
                <div className="login-form">
                    <h2>Login</h2>
                    {error && <p className="error-message">{error}</p>}
                    <form onSubmit={handleLogin}>
                        <input
                            type="email"
                            placeholder="Email"
                            value={email}
                            required
                            onChange={(e) => setEmail(e.target.value)}
                        />
                        <input
                            type="password"
                            placeholder="Password"
                            value={password}
                            required
                            onChange={(e) => setPassword(e.target.value)}
                        />
                        <button type="submit">Login</button>
                    </form>
                </div>
            </div>
        </div>
    );
}

export default Login;



