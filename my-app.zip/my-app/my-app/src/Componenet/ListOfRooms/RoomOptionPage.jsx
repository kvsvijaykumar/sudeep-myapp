import React from 'react';
import { useLocation } from 'react-router-dom';
import RoomOptions from '../ListOfRooms/RoomOptions';

const RoomOptionsPage = () => {
    const location = useLocation();
    const { hotel } = location.state || {};

    return (
        <div>
            <h1>{hotel.name} Room Options</h1>
            {hotel.rooms ? (
                <RoomOptions hotel={hotel} />
            ) : (
                <p>No room options available.</p>
            )}
        </div>
    );
};

export default RoomOptionsPage;
