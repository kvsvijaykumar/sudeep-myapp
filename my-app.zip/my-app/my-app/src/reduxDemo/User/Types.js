export const new_user = "new_user";
export const current_user = "current_user";
export const logout_user = "logout_user";
